# Solargy Africa

Nigeria's premier solar vendor directory — connecting homes and businesses with verified solar installers, panel dealers, battery suppliers, and consultants across all 37 Nigerian states.

---

## Project Structure

```
solargy-africa/
├── frontend/          React + Vite frontend app
├── backend/           Express 5 API server
├── shared/
│   ├── db/            PostgreSQL schema (Drizzle ORM)
│   ├── api-spec/      OpenAPI spec + Orval codegen config
│   ├── api-client-react/   Generated React Query hooks
│   └── api-zod/       Generated Zod validation schemas
└── README.md
```

---

## Requirements

- Node.js 18+
- npm or pnpm
- PostgreSQL database

---

## Setup & Running

### 1. Set environment variables

Create a `.env` file in the `backend/` folder:

```env
DATABASE_URL=postgresql://user:password@localhost:5432/solargy
ADMIN_SECRET=your-admin-secret
PORT=8080
NODE_ENV=development
```

### 2. Set up the database

```bash
cd shared/db
npm install
DATABASE_URL=postgresql://... npx drizzle-kit push
```

This creates all the required tables (`vendors`, `reviews`, `blog_posts`).

### 3. Start the backend

```bash
cd backend
npm install
node build.mjs           # compile the server
PORT=8080 node --enable-source-maps ./dist/index.mjs
```

### 4. Start the frontend

```bash
cd frontend
npm install
npm run dev              # runs on http://localhost:3000
```

Open your browser at **http://localhost:3000**

---

## Admin Panel

Visit `/admin` in the browser and enter the value of `ADMIN_SECRET` from your `.env` file.

Default key used in development: `solargy-admin-2024`

---

## Tech Stack

| Layer      | Technology                                |
|------------|-------------------------------------------|
| Frontend   | React 19, Vite, Tailwind CSS v4, wouter   |
| UI         | shadcn/ui components, Radix UI            |
| Data       | TanStack Query, Axios                     |
| Backend    | Express 5, Node.js                        |
| Database   | PostgreSQL, Drizzle ORM                   |
| Validation | Zod                                       |
| API        | OpenAPI 3.1 spec, Orval codegen           |

---

## Pages

| Route          | Description                        |
|----------------|------------------------------------|
| `/`            | Directory with search & filters    |
| `/vendor/:id`  | Full vendor profile + reviews      |
| `/blog`        | Solar knowledge hub                |
| `/blog/:slug`  | Full blog article                  |
| `/saved`       | Bookmarked vendors (localStorage)  |
| `/submit`      | Submit a new vendor listing        |
| `/admin`       | Admin panel (password protected)   |
| `/terms`       | Terms of Service                   |
| `/privacy`     | Privacy Policy                     |

---

## API Endpoints

| Method | Path                    | Description              |
|--------|-------------------------|--------------------------|
| GET    | /api/vendors            | List/search vendors      |
| GET    | /api/vendors/stats      | Directory stats          |
| GET    | /api/vendors/:id        | Single vendor            |
| POST   | /api/vendors            | Submit vendor listing    |
| GET    | /api/reviews/:vendorId  | Vendor reviews           |
| POST   | /api/reviews/:vendorId  | Submit a review          |
| GET    | /api/blog               | List blog posts          |
| GET    | /api/blog/:slug         | Single blog post         |
| POST   | /api/admin/vendors/:id/verify  | Verify a vendor   |
| DELETE | /api/admin/vendors/:id  | Delete a vendor          |
| POST   | /api/admin/blog         | Create blog post         |
| PUT    | /api/admin/blog/:id     | Edit blog post           |
| DELETE | /api/admin/blog/:id     | Delete blog post         |

Admin routes require the `x-admin-key` header set to your `ADMIN_SECRET` value.

---

## Contact

info@solargyafrica.com
