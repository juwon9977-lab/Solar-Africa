# Deploying Solargy Africa to Netlify

## Step 1 — Set up a free PostgreSQL database

Use any of these free Postgres providers:

| Provider | Free tier | Link |
|---|---|---|
| **Neon** (recommended) | 512 MB, always free | https://neon.tech |
| **Supabase** | 500 MB, always free | https://supabase.com |
| **Railway** | $5 free credit/month | https://railway.app |

After creating your database, run **`setup.sql`** in the SQL console to create all tables. The file is included in this zip.

Copy your **connection string** — it looks like:
```
postgresql://user:password@host/dbname
```

---

## Step 2 — Deploy to Netlify

1. Go to **https://netlify.com** and sign up (free)
2. Click **"Add new site" → "Deploy manually"**
3. **Drag and drop this entire folder** into the upload area
4. Wait for the deployment to finish

---

## Step 3 — Set environment variables

In your Netlify site dashboard, go to:
**Site configuration → Environment variables → Add a variable**

Add these two variables:

| Variable | Value |
|---|---|
| `DATABASE_URL` | Your PostgreSQL connection string from Step 1 |
| `ADMIN_SECRET` | A secret password for the admin panel (e.g. `my-secret-key`) |

Then go to **Deploys → Trigger deploy → Deploy site** to redeploy with the new variables.

---

## Step 4 — Done

Your site is live. Visit `/admin` and enter your `ADMIN_SECRET` to access the admin panel.

---

## How it works

- The static HTML/JS/CSS is served directly from Netlify's CDN (fast, global)
- All `/api/*` requests are handled by a **Netlify Function** (serverless Node.js)
- The function connects to your PostgreSQL database to read/write vendor and blog data
- No separate server is needed — Netlify handles everything

---

## Troubleshooting

**Blank page / 404 on navigation** — Make sure you uploaded the full folder including `netlify.toml`. That file tells Netlify to redirect all routes back to `index.html` for the SPA router.

**API errors / no vendor data** — Check that `DATABASE_URL` is set correctly in Netlify environment variables and that you ran `setup.sql` on your database.

**Admin panel says "Unauthorized"** — Make sure `ADMIN_SECRET` in Netlify matches what you type in the admin login prompt.
