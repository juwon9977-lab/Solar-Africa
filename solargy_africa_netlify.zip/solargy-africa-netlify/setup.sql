-- Solargy Africa — Database Setup
-- Run this SQL on your PostgreSQL database (e.g. Neon, Supabase, Railway)
-- before deploying to Netlify.

CREATE TABLE IF NOT EXISTS vendors (
  id          SERIAL PRIMARY KEY,
  name        TEXT NOT NULL,
  category    TEXT NOT NULL,
  state       TEXT NOT NULL,
  city        TEXT NOT NULL,
  phone       TEXT NOT NULL,
  whatsapp    TEXT NOT NULL,
  services    TEXT NOT NULL,
  description TEXT NOT NULL,
  logo        TEXT NOT NULL DEFAULT '',
  verified    BOOLEAN NOT NULL DEFAULT false,
  featured    BOOLEAN NOT NULL DEFAULT false,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS reviews (
  id            SERIAL PRIMARY KEY,
  vendor_id     INTEGER NOT NULL REFERENCES vendors(id) ON DELETE CASCADE,
  reviewer_name TEXT NOT NULL,
  rating        INTEGER NOT NULL CHECK (rating BETWEEN 1 AND 5),
  comment       TEXT NOT NULL,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS blog_posts (
  id           SERIAL PRIMARY KEY,
  title        TEXT NOT NULL,
  slug         TEXT NOT NULL UNIQUE,
  excerpt      TEXT NOT NULL,
  content      TEXT NOT NULL,
  author       TEXT NOT NULL,
  tags         TEXT[] NOT NULL DEFAULT '{}',
  read_minutes INTEGER NOT NULL DEFAULT 5,
  published_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Optional: seed some sample data to start with
INSERT INTO vendors (name, category, state, city, phone, whatsapp, services, description, logo, verified, featured)
VALUES
  ('SunPower Nigeria', 'Solar Installer', 'Lagos', 'Victoria Island', '+234 801 234 5678', '+234 801 234 5678', 'Residential installation, Commercial installation, Maintenance', 'Top-rated solar installation company serving Lagos and surrounding areas with over 500 completed projects.', 'SN', true, true),
  ('EcoEnergy Solutions', 'Panel Dealer', 'Abuja', 'Wuse II', '+234 802 345 6789', '+234 802 345 6789', 'Panel sales, Inverter sales, Battery sales', 'Leading solar panel dealer in Abuja, stocking Tier 1 panels from top global manufacturers.', 'ES', true, true)
ON CONFLICT DO NOTHING;

INSERT INTO blog_posts (title, slug, excerpt, content, author, tags, read_minutes)
VALUES (
  'How to Choose the Right Solar Installer in Nigeria',
  'how-to-choose-solar-installer-nigeria',
  'With hundreds of solar companies springing up across Nigeria, picking the right installer can be overwhelming. Here is what to look for.',
  '## What to Look For in a Solar Installer

Choosing a solar installer is one of the most important decisions you will make when going solar. Here are the key factors to consider:

### 1. Certification and Licensing
Ensure the installer is certified by the Rural Electrification Agency (REA) or a recognised industry body. Certified installers follow safety standards and quality practices.

### 2. Experience and Track Record
Ask for references and photos of completed installations. An experienced installer will have a portfolio and satisfied customers willing to speak on their behalf.

### 3. Warranties
A reputable installer offers both a workmanship warranty (typically 2–5 years) and will help you claim manufacturer warranties on panels, inverters, and batteries.

### 4. Transparent Pricing
Get at least three quotes. Be wary of prices that are too low — they often signal the use of substandard components.

### 5. After-Sales Support
Solar systems require occasional maintenance. Choose a company with a local presence and a clear maintenance plan.',
  'Solargy Editorial Team',
  ARRAY['Buying Guide', 'Installation'],
  5
) ON CONFLICT DO NOTHING;
