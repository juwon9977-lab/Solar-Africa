// Solargy Africa — Netlify Function API
// Handles all /api/* routes via a single function.
// Requires DATABASE_URL and ADMIN_SECRET environment variables set in Netlify.

const { Pool } = require("pg");

const pool = new Pool({ connectionString: process.env.DATABASE_URL, ssl: { rejectUnauthorized: false } });

const ADMIN_KEY = process.env.ADMIN_SECRET || "solargy-admin-2024";

function getInitials(name) {
  return name.split(" ").slice(0, 2).map((w) => w[0]?.toUpperCase() ?? "").join("");
}

function json(statusCode, body) {
  return {
    statusCode,
    headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" },
    body: JSON.stringify(body),
  };
}

function isAdmin(headers) {
  return headers["x-admin-key"] === ADMIN_KEY;
}

exports.handler = async (event) => {
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 200, headers: { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "*", "Access-Control-Allow-Methods": "*" }, body: "" };
  }

  // Strip /api prefix and leading slash
  const rawPath = (event.path || "").replace(/^\/?api/, "").replace(/\/$/, "") || "/";
  const method = event.httpMethod;
  const qs = event.queryStringParameters || {};
  let body = {};
  try { body = event.body ? JSON.parse(event.body) : {}; } catch (_) {}

  const client = await pool.connect();
  try {

    // ── GET /vendors/stats ────────────────────────────────────────────────────
    if (method === "GET" && rawPath === "/vendors/stats") {
      const [totals, verified, reviewCount, stateCounts, categoryCounts] = await Promise.all([
        client.query("SELECT COUNT(*)::int AS total FROM vendors"),
        client.query("SELECT COUNT(*)::int AS total FROM vendors WHERE verified = true"),
        client.query("SELECT COUNT(*)::int AS total FROM reviews"),
        client.query("SELECT state, COUNT(*)::int AS count FROM vendors GROUP BY state"),
        client.query("SELECT category, COUNT(*)::int AS count FROM vendors GROUP BY category"),
      ]);
      return json(200, {
        totalVendors: totals.rows[0].total,
        verifiedVendors: verified.rows[0].total,
        statesCovered: stateCounts.rows.length,
        totalReviews: reviewCount.rows[0].total,
        stateCounts: stateCounts.rows,
        categoryCounts: categoryCounts.rows,
      });
    }

    // ── GET /vendors ──────────────────────────────────────────────────────────
    if (method === "GET" && rawPath === "/vendors") {
      const conditions = [];
      const params = [];
      if (qs.state)    { params.push(qs.state);    conditions.push(`state = $${params.length}`); }
      if (qs.category) { params.push(qs.category); conditions.push(`category = $${params.length}`); }
      if (qs.q) {
        params.push(`%${qs.q}%`);
        conditions.push(`(name ILIKE $${params.length} OR description ILIKE $${params.length} OR services ILIKE $${params.length})`);
      }
      if (qs.verified !== undefined) { params.push(qs.verified === "true"); conditions.push(`verified = $${params.length}`); }
      if (qs.featured !== undefined) { params.push(qs.featured === "true"); conditions.push(`featured = $${params.length}`); }

      const where = conditions.length ? `WHERE ${conditions.join(" AND ")}` : "";
      const vendors = await client.query(
        `SELECT * FROM vendors ${where} ORDER BY featured DESC, created_at DESC`, params
      );

      if (vendors.rows.length === 0) return json(200, []);

      const ids = vendors.rows.map((v) => v.id);
      const ratings = await client.query(
        `SELECT vendor_id, ROUND(AVG(rating)::numeric, 1)::float AS avg_rating, COUNT(*)::int AS review_count
         FROM reviews WHERE vendor_id = ANY($1) GROUP BY vendor_id`,
        [ids]
      );
      const ratingMap = Object.fromEntries(ratings.rows.map((r) => [r.vendor_id, r]));

      return json(200, vendors.rows.map((v) => ({
        id: v.id,
        name: v.name,
        category: v.category,
        state: v.state,
        city: v.city,
        phone: v.phone,
        whatsapp: v.whatsapp,
        services: v.services,
        description: v.description,
        logo: v.logo,
        verified: v.verified,
        featured: v.featured,
        createdAt: v.created_at,
        rating: ratingMap[v.id]?.avg_rating ?? null,
        reviewCount: ratingMap[v.id]?.review_count ?? 0,
      })));
    }

    // ── GET /vendors/:id/reviews ──────────────────────────────────────────────
    const reviewsMatch = rawPath.match(/^\/vendors\/(\d+)\/reviews$/);
    if (reviewsMatch) {
      const vendorId = parseInt(reviewsMatch[1]);
      if (method === "GET") {
        const r = await client.query(
          "SELECT * FROM reviews WHERE vendor_id = $1 ORDER BY created_at DESC", [vendorId]
        );
        return json(200, r.rows.map((row) => ({
          id: row.id, vendorId: row.vendor_id, reviewerName: row.reviewer_name,
          rating: row.rating, comment: row.comment, createdAt: row.created_at,
        })));
      }
      if (method === "POST") {
        const { reviewerName, rating, comment } = body;
        if (!reviewerName || !rating || !comment) return json(400, { error: "reviewerName, rating and comment are required" });
        if (rating < 1 || rating > 5) return json(400, { error: "Rating must be between 1 and 5" });
        const vendor = await client.query("SELECT id FROM vendors WHERE id = $1", [vendorId]);
        if (!vendor.rows.length) return json(404, { error: "Vendor not found" });
        const r = await client.query(
          "INSERT INTO reviews (vendor_id, reviewer_name, rating, comment) VALUES ($1, $2, $3, $4) RETURNING *",
          [vendorId, reviewerName, rating, comment]
        );
        const row = r.rows[0];
        return json(201, { id: row.id, vendorId: row.vendor_id, reviewerName: row.reviewer_name, rating: row.rating, comment: row.comment, createdAt: row.created_at });
      }
    }

    // ── GET /vendors/:id ──────────────────────────────────────────────────────
    const vendorMatch = rawPath.match(/^\/vendors\/(\d+)$/);
    if (vendorMatch) {
      const id = parseInt(vendorMatch[1]);
      if (method === "GET") {
        const v = await client.query("SELECT * FROM vendors WHERE id = $1", [id]);
        if (!v.rows.length) return json(404, { error: "Vendor not found" });
        const row = v.rows[0];
        const r = await client.query(
          "SELECT ROUND(AVG(rating)::numeric, 1)::float AS avg_rating, COUNT(*)::int AS review_count FROM reviews WHERE vendor_id = $1",
          [id]
        );
        const rs = r.rows[0];
        return json(200, {
          id: row.id, name: row.name, category: row.category, state: row.state,
          city: row.city, phone: row.phone, whatsapp: row.whatsapp,
          services: row.services, description: row.description, logo: row.logo,
          verified: row.verified, featured: row.featured, createdAt: row.created_at,
          rating: rs.avg_rating ?? null, reviewCount: rs.review_count ?? 0,
        });
      }
    }

    // ── POST /vendors ─────────────────────────────────────────────────────────
    if (method === "POST" && rawPath === "/vendors") {
      const { name, category, state, city, phone, whatsapp, services, description } = body;
      if (!name || !category || !state || !city || !phone || !whatsapp || !services || !description)
        return json(400, { error: "All fields are required" });
      const logo = getInitials(name);
      const r = await client.query(
        `INSERT INTO vendors (name, category, state, city, phone, whatsapp, services, description, logo)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING *`,
        [name, category, state, city, phone, whatsapp, services, description, logo]
      );
      const row = r.rows[0];
      return json(201, { ...row, createdAt: row.created_at, rating: null, reviewCount: 0 });
    }

    // ── GET /blog ─────────────────────────────────────────────────────────────
    if (method === "GET" && rawPath === "/blog") {
      let result;
      if (qs.tag) {
        result = await client.query(
          "SELECT * FROM blog_posts WHERE $1 = ANY(tags) ORDER BY published_at DESC", [qs.tag]
        );
      } else {
        result = await client.query("SELECT * FROM blog_posts ORDER BY published_at DESC");
      }
      return json(200, result.rows.map((p) => ({
        id: p.id, title: p.title, slug: p.slug, excerpt: p.excerpt, content: p.content,
        author: p.author, tags: p.tags, readMinutes: p.read_minutes, publishedAt: p.published_at,
      })));
    }

    // ── GET /blog/:slug ───────────────────────────────────────────────────────
    const blogMatch = rawPath.match(/^\/blog\/([^/]+)$/);
    if (blogMatch && method === "GET") {
      const slug = blogMatch[1];
      const r = await client.query("SELECT * FROM blog_posts WHERE slug = $1", [slug]);
      if (!r.rows.length) return json(404, { error: "Blog post not found" });
      const p = r.rows[0];
      return json(200, {
        id: p.id, title: p.title, slug: p.slug, excerpt: p.excerpt, content: p.content,
        author: p.author, tags: p.tags, readMinutes: p.read_minutes, publishedAt: p.published_at,
      });
    }

    // ── Admin: PATCH /blog/id/:id ─────────────────────────────────────────────
    const blogIdMatch = rawPath.match(/^\/blog\/id\/(\d+)$/);
    if (blogIdMatch) {
      if (!isAdmin(event.headers)) return json(401, { error: "Unauthorized" });
      const id = parseInt(blogIdMatch[1]);
      if (method === "DELETE") {
        const r = await client.query("DELETE FROM blog_posts WHERE id = $1 RETURNING id", [id]);
        if (!r.rows.length) return json(404, { error: "Not found" });
        return { statusCode: 204, body: "" };
      }
      if (method === "PATCH") {
        const fields = Object.entries(body).filter(([k]) =>
          ["title","slug","excerpt","content","author","tags","readMinutes"].includes(k)
        );
        if (!fields.length) return json(400, { error: "No fields to update" });
        const colMap = { readMinutes: "read_minutes" };
        const setClause = fields.map(([k], i) => `${colMap[k] || k} = $${i + 1}`).join(", ");
        const values = fields.map(([, v]) => v);
        values.push(id);
        const r = await client.query(
          `UPDATE blog_posts SET ${setClause} WHERE id = $${values.length} RETURNING *`, values
        );
        if (!r.rows.length) return json(404, { error: "Not found" });
        const p = r.rows[0];
        return json(200, { id: p.id, title: p.title, slug: p.slug, excerpt: p.excerpt, content: p.content, author: p.author, tags: p.tags, readMinutes: p.read_minutes, publishedAt: p.published_at });
      }
    }

    // ── Admin: vendor verify/feature/delete ───────────────────────────────────
    const adminVendorMatch = rawPath.match(/^\/admin\/vendors\/(\d+)(\/verify|\/feature)?$/);
    if (adminVendorMatch) {
      if (!isAdmin(event.headers)) return json(401, { error: "Unauthorized" });
      const id = parseInt(adminVendorMatch[1]);
      const action = adminVendorMatch[2];
      if (method === "POST" && action === "/verify") {
        await client.query("UPDATE vendors SET verified = true WHERE id = $1", [id]);
        return json(200, { ok: true });
      }
      if (method === "POST" && action === "/feature") {
        const cur = await client.query("SELECT featured FROM vendors WHERE id = $1", [id]);
        if (!cur.rows.length) return json(404, { error: "Not found" });
        await client.query("UPDATE vendors SET featured = $1 WHERE id = $2", [!cur.rows[0].featured, id]);
        return json(200, { ok: true });
      }
      if (method === "DELETE") {
        await client.query("DELETE FROM vendors WHERE id = $1", [id]);
        return { statusCode: 204, body: "" };
      }
    }

    return json(404, { error: "Not found" });

  } catch (err) {
    console.error("API error:", err);
    return json(500, { error: "Internal server error" });
  } finally {
    client.release();
  }
};
